export interface SwitchProps {
    id?: string;
    label: string;
    checked?: boolean;
    onChange?: (checked: boolean) => void;
    variant?: "primary" | "success" | "danger";
    size?: "sm" | "md" | "lg";
    error?: string;
    disabled?: boolean;
    required?: boolean;
    className?: string;
    switchClassName?: string;
    labelClassName?: string;
}
